// Copyright 2022 yala <zhaojunchao@loongson.cn>;<junchao82@qq.com>
// Copyright 2026 Tencent
// SPDX-License-Identifier: BSD-3-Clause

#ifndef LAYER_CONVOLUTION1D_LOONGARCH_H
#define LAYER_CONVOLUTION1D_LOONGARCH_H

#include "convolution1d.h"

namespace ncnn {

class Convolution1D_loongarch : public Convolution1D
{
public:
    Convolution1D_loongarch();

    virtual int create_pipeline(const Option& opt);
    virtual int destroy_pipeline(const Option& opt);

    virtual int forward(const Mat& bottom_blob, Mat& top_blob, const Option& opt) const;

    virtual int forward(const std::vector<Mat>& bottom_blobs, std::vector<Mat>& top_blobs, const Option& opt) const;

protected:
#if NCNN_BF16
    int create_pipeline_bf16s(const Option& opt);
    int forward_bf16s(const Mat& bottom_blob, Mat& top_blob, const Option& opt) const;
#endif

public:
    Mat weight_data_tm;
};

} // namespace ncnn

#endif // LAYER_CONVOLUTION1D_LOONGARCH_H
