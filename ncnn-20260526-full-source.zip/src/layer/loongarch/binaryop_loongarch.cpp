// Copyright 2022 yala <zhaojunchao@loongson.cn>;<junchao82@qq.com>
// SPDX-License-Identifier: BSD-3-Clause

#include "binaryop_loongarch.h"

#if __loongarch_sx
#include <lsxintrin.h>
#include "lsx_mathfun.h"
#include "loongarch_usability.h"
#endif // __loongarch_sx

#if __loongarch_sx
#if __loongarch_asx
#include <lasxintrin.h>
#include "lasx_mathfun.h"
#endif // __loongarch_asx
#endif // __loongarch_sx

#include "cpu.h"

namespace ncnn {

BinaryOp_loongarch::BinaryOp_loongarch()
{
#if __loongarch_sx
    support_packing = true;
#endif // __loongarch_sx
#if NCNN_BF16
    support_bf16_storage = true;
#endif
}

template<typename Op>
static void binary_op_vector_no_broadcast(const float* ptr, const float* ptr1, float* outptr, int size)
{
    const Op op;

    int i = 0;
#if __loongarch_sx
#if __loongarch_asx
    for (; i + 7 < size; i += 8)
    {
        __builtin_prefetch(ptr + 32);
        __builtin_prefetch(ptr1 + 32);
        __m256 _p = (__m256)__lasx_xvld(ptr, 0);
        __m256 _b = (__m256)__lasx_xvld(ptr1, 0);
        __m256 _outp = op(_p, _b);
        __lasx_xvst(_outp, outptr, 0);
        ptr += 8;
        ptr1 += 8;
        outptr += 8;
    }
#endif // __loongarch_asx
    for (; i + 3 < size; i += 4)
    {
        __builtin_prefetch(ptr + 16);
        __builtin_prefetch(ptr1 + 16);
        __m128 _p = (__m128)__lsx_vld(ptr, 0);
        __m128 _b = (__m128)__lsx_vld(ptr1, 0);
        __m128 _outp = op(_p, _b);
        __lsx_vst(_outp, outptr, 0);
        ptr += 4;
        ptr1 += 4;
        outptr += 4;
    }
#endif // __loongarch_sx
    for (; i < size; i++)
    {
        *outptr = op(*ptr, *ptr1);
        ptr += 1;
        ptr1 += 1;
        outptr += 1;
    }
}

template<typename Op>
static void binary_op_vector_broadcast_b(const float* ptr, const float* ptr1, float* outptr, int size, int elempack)
{
    const Op op;

    const float b = *ptr1;
    int i = 0;
#if __loongarch_sx
    __m128 _b_128 = (elempack == 4) ? (__m128)__lsx_vld(ptr1, 0) : __lsx_vreplfr2vr_s(b);
#if __loongarch_asx
    __m256 _b_256 = (elempack == 8) ? (__m256)__lasx_xvld(ptr1, 0) : __lasx_concat_128_s(_b_128, _b_128);
    for (; i + 7 < size; i += 8)
    {
        __builtin_prefetch(ptr + 32);
        __m256 _p = (__m256)__lasx_xvld(ptr, 0);
        __m256 _outp = op(_p, _b_256);
        __lasx_xvst(_outp, outptr, 0);
        ptr += 8;
        outptr += 8;
    }
#endif // __loongarch_asx
    for (; i + 3 < size; i += 4)
    {
        __builtin_prefetch(ptr + 16);
        __m128 _p = (__m128)__lsx_vld(ptr, 0);
        __m128 _outp = op(_p, _b_128);
        __lsx_vst(_outp, outptr, 0);
        ptr += 4;
        outptr += 4;
    }
#endif // __loongarch_sx
    for (; i < size; i++)
    {
        *outptr = op(*ptr, b);
        ptr += 1;
        outptr += 1;
    }
}

template<typename Op>
static void binary_op_vector_broadcast_a(const float* ptr, const float* ptr1, float* outptr, int size, int elempack)
{
    const Op op;

    const float a = *ptr;
    int i = 0;
#if __loongarch_sx
    __m128 _a_128 = (elempack == 4) ? (__m128)__lsx_vld(ptr, 0) : __lsx_vreplfr2vr_s(a);
#if __loongarch_asx
    __m256 _a_256 = (elempack == 8) ? (__m256)__lasx_xvld(ptr, 0) : __lasx_concat_128_s(_a_128, _a_128);
    for (; i + 7 < size; i += 8)
    {
        __builtin_prefetch(ptr1 + 32);
        __m256 _b = (__m256)__lasx_xvld(ptr1, 0);
        __m256 _outp = op(_a_256, _b);
        __lasx_xvst(_outp, outptr, 0);
        ptr1 += 8;
        outptr += 8;
    }
#endif // __loongarch_asx
    for (; i + 3 < size; i += 4)
    {
        __builtin_prefetch(ptr1 + 16);
        __m128 _b = (__m128)__lsx_vld(ptr1, 0);
        __m128 _outp = op(_a_128, _b);
        __lsx_vst(_outp, outptr, 0);
        ptr1 += 4;
        outptr += 4;
    }
#endif // __loongarch_sx
    for (; i < size; i++)
    {
        *outptr = op(a, *ptr1);
        ptr1 += 1;
        outptr += 1;
    }
}

template<typename Op>
static void binary_op_vector_broadcast_pb(const float* ptr, const float* ptr1, float* outptr, int w, int elempack)
{
    const Op op;

#if __loongarch_sx
#if __loongarch_asx
    if (elempack == 8)
    {
        int i = 0;
        for (; i < w; i++)
        {
            __builtin_prefetch(ptr + 32);
            __m256 _p = (__m256)__lasx_xvld(ptr, 0);
            __m256 _b = __lasx_xvreplfr2vr_s(*ptr1);
            __m256 _outp = op(_p, _b);
            __lasx_xvst(_outp, outptr, 0);
            ptr += 8;
            ptr1 += 1;
            outptr += 8;
        }
    }
#endif // __loongarch_asx
    if (elempack == 4)
    {
        int i = 0;
        for (; i < w; i++)
        {
            __builtin_prefetch(ptr + 16);
            __m128 _p = (__m128)__lsx_vld(ptr, 0);
            __m128 _b = __lsx_vreplfr2vr_s(*ptr1);
            __m128 _outp = op(_p, _b);
            __lsx_vst(_outp, outptr, 0);
            ptr += 4;
            ptr1 += 1;
            outptr += 4;
        }
    }
#endif // __loongarch_sx
}

template<typename Op>
static void binary_op_vector_broadcast_pb_b(const float* ptr, const float* ptr1, float* outptr, int w, int elempack)
{
    const Op op;

    const int size = w * elempack;

    int i = 0;
#if __loongarch_sx
#if __loongarch_asx
    __m256 _b_256 = __lasx_xvreplfr2vr_s(*ptr1);
    for (; i + 7 < size; i += 8)
    {
        __builtin_prefetch(ptr + 32);
        __m256 _p = (__m256)__lasx_xvld(ptr, 0);
        __m256 _outp = op(_p, _b_256);
        __lasx_xvst(_outp, outptr, 0);
        ptr += 8;
        outptr += 8;
    }
#endif // __loongarch_asx
    __m128 _b = __lsx_vreplfr2vr_s(*ptr1);
    for (; i + 3 < size; i += 4)
    {
        __builtin_prefetch(ptr + 16);
        __m128 _p = (__m128)__lsx_vld(ptr, 0);
        __m128 _outp = op(_p, _b);
        __lsx_vst(_outp, outptr, 0);
        ptr += 4;
        outptr += 4;
    }
#endif // __loongarch_sx
}

template<typename Op>
static void binary_op_vector_broadcast_pb_a(const float* ptr, const float* ptr1, float* outptr, int w, int elempack)
{
    const Op op;

#if __loongarch_sx
#if __loongarch_asx
    if (elempack == 8)
    {
        int i = 0;
        __m256 _p = (__m256)__lasx_xvld(ptr, 0);
        for (; i < w; i++)
        {
            __m256 _b = __lasx_xvreplfr2vr_s(*ptr1);
            __m256 _outp = op(_p, _b);
            __lasx_xvst(_outp, outptr, 0);
            ptr1 += 1;
            outptr += 8;
        }
    }
#endif // __loongarch_asx
    if (elempack == 4)
    {
        int i = 0;
        __m128 _p = (__m128)__lsx_vld(ptr, 0);
        for (; i < w; i++)
        {
            __m128 _b = __lsx_vreplfr2vr_s(*ptr1);
            __m128 _outp = op(_p, _b);
            __lsx_vst(_outp, outptr, 0);
            ptr1 += 1;
            outptr += 4;
        }
    }
#endif // __loongarch_sx
}

template<typename Op>
static void binary_op_vector(const float* ptr, const float* ptr1, float* outptr, int aw, int bw, int ap, int bp)
{
    const int w = std::max(aw, bw);
    const int elempack = std::max(ap, bp);
    const int size = w * elempack;

    if (ap == bp)
    {
        if (aw == bw)
        {
            // no broadcast
            return binary_op_vector_no_broadcast<Op>(ptr, ptr1, outptr, size);
        }

        if (bw == 1)
        {
            // broadcast single b
            return binary_op_vector_broadcast_b<Op>(ptr, ptr1, outptr, size, elempack);
        }

        if (aw == 1)
        {
            // broadcast single a
            return binary_op_vector_broadcast_a<Op>(ptr, ptr1, outptr, size, elempack);
        }
    }

    if (bp == 1)
    {
        if (aw == bw)
        {
            // broadcast pack1 b
            return binary_op_vector_broadcast_pb<Op>(ptr, ptr1, outptr, w, elempack);
        }

        if (bw == 1)
        {
            // broadcast pack1 single b
            return binary_op_vector_broadcast_pb_b<Op>(ptr, ptr1, outptr, w, elempack);
        }

        if (aw == 1)
        {
            // broadcast single a and pack1 b
            return binary_op_vector_broadcast_pb_a<Op>(ptr, ptr1, outptr, w, elempack);
        }
    }

    // shall never reach here
}

template<typename Op>
static int binary_op_scalar_inplace(Mat& a, float b, const Option& opt)
{
    Op op;

    const int channels = a.c;
    const int size = a.w * a.h * a.d * a.elempack;

    #pragma omp parallel for num_threads(opt.num_threads)
    for (int q = 0; q < channels; q++)
    {
        float* ptr = a.channel(q);

        int i = 0;
#if __loongarch_sx
#if __loongarch_asx
        __m256 _b_256 = __lasx_xvreplfr2vr_s(b);
        for (; i + 7 < size; i += 8)
        {
            __builtin_prefetch(ptr + 32);
            __m256 _p = (__m256)__lasx_xvld(ptr, 0);
            _p = op(_p, _b_256);
            __lasx_xvst(_p, ptr, 0);
            ptr += 8;
        }
#endif // __loongarch_asx
        __m128 _b = __lsx_vreplfr2vr_s(b);
        for (; i + 3 < size; i += 4)
        {
            __builtin_prefetch(ptr + 16);
            __m128 _p = (__m128)__lsx_vld(ptr, 0);
            _p = op(_p, _b);
            __lsx_vst(_p, ptr, 0);
            ptr += 4;
        }
#endif // __loongarch_sx
        for (; i < size; i++)
        {
            *ptr = op(*ptr, b);
            ptr++;
        }
    }

    return 0;
}

namespace BinaryOp_loongarch_functor {

#if __loongarch_sx
#if __loongarch_asx
#define MAKE_FUNCTION(NAME, IMPL, IMPL4, IMPL8)                   \
    struct NAME                                                   \
    {                                                             \
        float operator()(const float& x, const float& y) const    \
        {                                                         \
            return IMPL;                                          \
        }                                                         \
        __m128 operator()(const __m128& x, const __m128& y) const \
        {                                                         \
            return IMPL4;                                         \
        }                                                         \
        __m256 operator()(const __m256& x, const __m256& y) const \
        {                                                         \
            return IMPL8;                                         \
        }                                                         \
    };
#else
#define MAKE_FUNCTION(NAME, IMPL, IMPL4, IMPL8)                   \
    struct NAME                                                   \
    {                                                             \
        float operator()(const float& x, const float& y) const    \
        {                                                         \
            return IMPL;                                          \
        }                                                         \
        __m128 operator()(const __m128& x, const __m128& y) const \
        {                                                         \
            return IMPL4;                                         \
        }                                                         \
    };
#endif // __loongarch_asx
#else
#define MAKE_FUNCTION(NAME, IMPL, IMPL4, IMPL8)                \
    struct NAME                                                \
    {                                                          \
        float operator()(const float& x, const float& y) const \
        {                                                      \
            return IMPL;                                       \
        }                                                      \
    };
#endif // __loongarch_sx

// clang-format off
// *INDENT-OFF*
MAKE_FUNCTION(binary_op_add, x + y, __lsx_vfadd_s(x, y), __lasx_xvfadd_s(x, y))
MAKE_FUNCTION(binary_op_sub, x - y, __lsx_vfsub_s(x, y), __lasx_xvfsub_s(x, y))
MAKE_FUNCTION(binary_op_mul, x * y, __lsx_vfmul_s(x, y), __lasx_xvfmul_s(x, y))
MAKE_FUNCTION(binary_op_div, x / y, __lsx_vfdiv_s(x, y), __lasx_xvfdiv_s(x, y))
MAKE_FUNCTION(binary_op_max, std::max(x, y), __lsx_vfmax_s(x, y), __lasx_xvfmax_s(x, y))
MAKE_FUNCTION(binary_op_min, std::min(x, y), __lsx_vfmin_s(x, y), __lasx_xvfmin_s(x, y))
MAKE_FUNCTION(binary_op_pow, (float)powf(x, y), pow_ps(x, y), pow256_ps(x, y))
MAKE_FUNCTION(binary_op_rsub, y - x, __lsx_vfsub_s(y, x), __lasx_xvfsub_s(y, x))
MAKE_FUNCTION(binary_op_rdiv, y / x, __lsx_vfdiv_s(y, x), __lasx_xvfdiv_s(y, x))
MAKE_FUNCTION(binary_op_rpow, (float)powf(y, x), pow_ps(y, x), pow256_ps(y, x))
MAKE_FUNCTION(binary_op_atan2, (float)atan2f(x, y), atan2_ps(x, y), atan2256_ps(x, y))
MAKE_FUNCTION(binary_op_ratan2, (float)atan2f(y, x), atan2_ps(y, x), atan2256_ps(y, x))
MAKE_FUNCTION(binary_op_fmod, (float)fmodf(x, y), fmod_ps(x, y), fmod256_ps(x, y))
MAKE_FUNCTION(binary_op_rfmod, (float)fmodf(y, x), fmod_ps(y, x), fmod256_ps(y, x))
MAKE_FUNCTION(binary_op_logaddexp, (float)(std::max(x, y) + log1pf(expf(std::min(x, y) - std::max(x, y)))), logaddexp_ps(x, y), logaddexp256_ps(x, y))
MAKE_FUNCTION(binary_op_floor_divide, (float)floorf(x / y), floor_divide_ps(x, y), floor_divide256_ps(x, y))
MAKE_FUNCTION(binary_op_rfloor_divide, (float)floorf(y / x), floor_divide_ps(y, x), floor_divide256_ps(y, x))
MAKE_FUNCTION(binary_op_remainder, (float)remainderf(x, y), remainder_ps(x, y), remainder256_ps(x, y))
MAKE_FUNCTION(binary_op_rremainder, (float)remainderf(y, x), remainder_ps(y, x), remainder256_ps(y, x))
// *INDENT-ON*
// clang-format on

#undef MAKE_FUNCTION

} // namespace BinaryOp_loongarch_functor

#if NCNN_BF16
template<typename Op>
static void binary_op_vector_no_broadcast_bf16s(const unsigned short* ptr, const unsigned short* ptr1, unsigned short* outptr, int size)
{
    const Op op;

    int i = 0;
#if __loongarch_sx
#if __loongarch_asx
    for (; i + 7 < size; i += 8)
    {
        __m256 _p = bfloat2float_lasx((__m128i)__lsx_vld(ptr, 0));
        __m256 _b = bfloat2float_lasx((__m128i)__lsx_vld(ptr1, 0));
        __m256 _outp = op(_p, _b);
        __lsx_vst(float2bfloat_lasx(_outp), outptr, 0);
        ptr += 8;
        ptr1 += 8;
        outptr += 8;
    }
#else  // __loongarch_asx
    {
        __m128i _zero = __lsx_vreplgr2vr_w(0);
        for (; i + 7 < size; i += 8)
        {
            __m128i _p01 = __lsx_vld(ptr, 0);
            __m128i _b01 = __lsx_vld(ptr1, 0);
            __m128 _p0 = (__m128)__lsx_vilvl_h(_p01, _zero);
            __m128 _p1 = (__m128)__lsx_vilvh_h(_p01, _zero);
            __m128 _b0 = (__m128)__lsx_vilvl_h(_b01, _zero);
            __m128 _b1 = (__m128)__lsx_vilvh_h(_b01, _zero);
            __m128 _outp0 = op(_p0, _b0);
            __m128 _outp1 = op(_p1, _b1);
            __lsx_vst(float2bfloat_lsx(_outp0, _outp1), outptr, 0);
            ptr += 8;
            ptr1 += 8;
            outptr += 8;
        }
    }
#endif // __loongarch_asx
    for (; i + 3 < size; i += 4)
    {
        __m128 _p = bfloat2float_lsx(__lsx_vldrepl_d(ptr, 0));
        __m128 _b = bfloat2float_lsx(__lsx_vldrepl_d(ptr1, 0));
        __m128 _outp = op(_p, _b);
        __lsx_vstelm_d(float2bfloat_lsx(_outp), outptr, 0, 0);
        ptr += 4;
        ptr1 += 4;
        outptr += 4;
    }
#endif // __loongarch_sx
    for (; i < size; i++)
    {
        *outptr++ = float32_to_bfloat16(op(bfloat16_to_float32(*ptr++), bfloat16_to_float32(*ptr1++)));
    }
}

template<typename Op>
static void binary_op_vector_broadcast_b_bf16s(const unsigned short* ptr, const unsigned short* ptr1, unsigned short* outptr, int size, int elempack)
{
    const Op op;

    const float b = bfloat16_to_float32(*ptr1);

    int i = 0;
#if __loongarch_sx
    __m128 _b_128 = (elempack == 4) ? bfloat2float_lsx(__lsx_vldrepl_d(ptr1, 0)) : (__m128)__lsx_vreplfr2vr_s(b);
#if __loongarch_asx
    __m256 _b_256 = (elempack == 8) ? bfloat2float_lasx((__m128i)__lsx_vld(ptr1, 0)) : __lasx_concat_128_s(_b_128, _b_128);
    for (; i + 7 < size; i += 8)
    {
        __m256 _p = bfloat2float_lasx((__m128i)__lsx_vld(ptr, 0));
        __m256 _outp = op(_p, _b_256);
        __lsx_vst(float2bfloat_lasx(_outp), outptr, 0);
        ptr += 8;
        outptr += 8;
    }
#else  // __loongarch_asx
    {
        __m128i _zero = __lsx_vreplgr2vr_w(0);
        __m128 _b0 = _b_128;
        __m128 _b1 = _b_128;
        if (elempack == 8)
        {
            __m128i _b01 = __lsx_vld(ptr1, 0);
            _b0 = (__m128)__lsx_vilvl_h(_b01, _zero);
            _b1 = (__m128)__lsx_vilvh_h(_b01, _zero);
        }
        for (; i + 7 < size; i += 8)
        {
            __m128i _p01 = __lsx_vld(ptr, 0);
            __m128 _p0 = (__m128)__lsx_vilvl_h(_p01, _zero);
            __m128 _p1 = (__m128)__lsx_vilvh_h(_p01, _zero);
            __m128 _outp0 = op(_p0, _b0);
            __m128 _outp1 = op(_p1, _b1);
            __lsx_vst(float2bfloat_lsx(_outp0, _outp1), outptr, 0);
            ptr += 8;
            outptr += 8;
        }
    }
#endif // __loongarch_asx
    for (; i + 3 < size; i += 4)
    {
        __m128 _p = bfloat2float_lsx(__lsx_vldrepl_d(ptr, 0));
        __m128 _outp = op(_p, _b_128);
        __lsx_vstelm_d(float2bfloat_lsx(_outp), outptr, 0, 0);
        ptr += 4;
        outptr += 4;
    }
#endif // __loongarch_sx
    for (; i < size; i++)
    {
        *outptr++ = float32_to_bfloat16(op(bfloat16_to_float32(*ptr++), b));
    }
}

template<typename Op>
static void binary_op_vector_broadcast_a_bf16s(const unsigned short* ptr, const unsigned short* ptr1, unsigned short* outptr, int size, int elempack)
{
    const Op op;

    const float a = bfloat16_to_float32(*ptr);

    int i = 0;
#if __loongarch_sx
    __m128 _a_128 = (elempack == 4) ? bfloat2float_lsx(__lsx_vldrepl_d(ptr, 0)) : (__m128)__lsx_vreplfr2vr_s(a);
#if __loongarch_asx
    __m256 _a_256 = (elempack == 8) ? bfloat2float_lasx((__m128i)__lsx_vld(ptr, 0)) : __lasx_concat_128_s(_a_128, _a_128);
    for (; i + 7 < size; i += 8)
    {
        __m256 _b = bfloat2float_lasx((__m128i)__lsx_vld(ptr1, 0));
        __m256 _outp = op(_a_256, _b);
        __lsx_vst(float2bfloat_lasx(_outp), outptr, 0);
        ptr1 += 8;
        outptr += 8;
    }
#else  // __loongarch_asx
    {
        __m128i _zero = __lsx_vreplgr2vr_w(0);
        __m128 _a0 = _a_128;
        __m128 _a1 = _a_128;
        if (elempack == 8)
        {
            __m128i _a01 = __lsx_vld(ptr, 0);
            _a0 = (__m128)__lsx_vilvl_h(_a01, _zero);
            _a1 = (__m128)__lsx_vilvh_h(_a01, _zero);
        }
        for (; i + 7 < size; i += 8)
        {
            __m128i _b01 = __lsx_vld(ptr1, 0);
            __m128 _b0 = (__m128)__lsx_vilvl_h(_b01, _zero);
            __m128 _b1 = (__m128)__lsx_vilvh_h(_b01, _zero);
            __m128 _outp0 = op(_a0, _b0);
            __m128 _outp1 = op(_a1, _b1);
            __lsx_vst(float2bfloat_lsx(_outp0, _outp1), outptr, 0);
            ptr1 += 8;
            outptr += 8;
        }
    }
#endif // __loongarch_asx
    for (; i + 3 < size; i += 4)
    {
        __m128 _b = bfloat2float_lsx(__lsx_vldrepl_d(ptr1, 0));
        __m128 _outp = op(_a_128, _b);
        __lsx_vstelm_d(float2bfloat_lsx(_outp), outptr, 0, 0);
        ptr1 += 4;
        outptr += 4;
    }
#endif // __loongarch_sx
    for (; i < size; i++)
    {
        *outptr++ = float32_to_bfloat16(op(a, bfloat16_to_float32(*ptr1++)));
    }
}

template<typename Op>
static void binary_op_vector_broadcast_pb_bf16s(const unsigned short* ptr, const unsigned short* ptr1, unsigned short* outptr, int w, int elempack)
{
    const Op op;

#if __loongarch_sx
#if __loongarch_asx
    if (elempack == 8)
    {
        for (int i = 0; i < w; i++)
        {
            __m256 _p = bfloat2float_lasx((__m128i)__lsx_vld(ptr, 0));
            __m256 _b = __lasx_xvreplfr2vr_s(bfloat16_to_float32(*ptr1));
            __m256 _outp = op(_p, _b);
            __lsx_vst(float2bfloat_lasx(_outp), outptr, 0);
            ptr += 8;
            ptr1 += 1;
            outptr += 8;
        }
    }
#else  // __loongarch_asx
    if (elempack == 8)
    {
        __m128i _zero = __lsx_vreplgr2vr_w(0);
        for (int i = 0; i < w; i++)
        {
            __m128i _p01 = __lsx_vld(ptr, 0);
            __m128 _p0 = (__m128)__lsx_vilvl_h(_p01, _zero);
            __m128 _p1 = (__m128)__lsx_vilvh_h(_p01, _zero);
            __m128 _b = (__m128)__lsx_vreplfr2vr_s(bfloat16_to_float32(*ptr1));
            __m128 _outp0 = op(_p0, _b);
            __m128 _outp1 = op(_p1, _b);
            __lsx_vst(float2bfloat_lsx(_outp0, _outp1), outptr, 0);
            ptr += 8;
            ptr1 += 1;
            outptr += 8;
        }
    }
#endif // __loongarch_asx

    if (elempack == 4)
    {
        int i = 0;
        __m128i _zero = __lsx_vreplgr2vr_w(0);
        for (; i + 1 < w; i += 2)
        {
            __m128i _p01 = __lsx_vld(ptr, 0);
            __m128 _p0 = (__m128)__lsx_vilvl_h(_p01, _zero);
            __m128 _p1 = (__m128)__lsx_vilvh_h(_p01, _zero);
            __m128 _b0 = (__m128)__lsx_vreplfr2vr_s(bfloat16_to_float32(ptr1[0]));
            __m128 _b1 = (__m128)__lsx_vreplfr2vr_s(bfloat16_to_float32(ptr1[1]));
            __m128 _outp0 = op(_p0, _b0);
            __m128 _outp1 = op(_p1, _b1);
            __lsx_vst(float2bfloat_lsx(_outp0, _outp1), outptr, 0);
            ptr += 8;
            ptr1 += 2;
            outptr += 8;
        }
        for (; i < w; i++)
        {
            __m128 _p = bfloat2float_lsx(__lsx_vldrepl_d(ptr, 0));
            __m128 _b = (__m128)__lsx_vreplfr2vr_s(bfloat16_to_float32(*ptr1));
            __m128 _outp = op(_p, _b);
            __lsx_vstelm_d(float2bfloat_lsx(_outp), outptr, 0, 0);
            ptr += 4;
            ptr1 += 1;
            outptr += 4;
        }
    }
#endif // __loongarch_sx
}

template<typename Op>
static void binary_op_vector_broadcast_pb_b_bf16s(const unsigned short* ptr, const unsigned short* ptr1, unsigned short* outptr, int w, int elempack)
{
    const Op op;

    const int size = w * elempack;
    const float b = bfloat16_to_float32(*ptr1);

    int i = 0;
#if __loongarch_sx
#if __loongarch_asx
    {
        __m256 _b_256 = __lasx_xvreplfr2vr_s(b);
        for (; i + 7 < size; i += 8)
        {
            __m256 _p = bfloat2float_lasx((__m128i)__lsx_vld(ptr, 0));
            __m256 _outp = op(_p, _b_256);
            __lsx_vst(float2bfloat_lasx(_outp), outptr, 0);
            ptr += 8;
            outptr += 8;
        }
    }
#else  // __loongarch_asx
    {
        __m128i _zero = __lsx_vreplgr2vr_w(0);
        __m128 _b_128 = (__m128)__lsx_vreplfr2vr_s(b);
        for (; i + 7 < size; i += 8)
        {
            __m128i _p01 = __lsx_vld(ptr, 0);
            __m128 _p0 = (__m128)__lsx_vilvl_h(_p01, _zero);
            __m128 _p1 = (__m128)__lsx_vilvh_h(_p01, _zero);
            __m128 _outp0 = op(_p0, _b_128);
            __m128 _outp1 = op(_p1, _b_128);
            __lsx_vst(float2bfloat_lsx(_outp0, _outp1), outptr, 0);
            ptr += 8;
            outptr += 8;
        }
    }
#endif // __loongarch_asx
    {
        __m128 _b_128 = (__m128)__lsx_vreplfr2vr_s(b);
        for (; i + 3 < size; i += 4)
        {
            __m128 _p = bfloat2float_lsx(__lsx_vldrepl_d(ptr, 0));
            __m128 _outp = op(_p, _b_128);
            __lsx_vstelm_d(float2bfloat_lsx(_outp), outptr, 0, 0);
            ptr += 4;
            outptr += 4;
        }
    }
#endif // __loongarch_sx
}

template<typename Op>
static void binary_op_vector_broadcast_pb_a_bf16s(const unsigned short* ptr, const unsigned short* ptr1, unsigned short* outptr, int w, int elempack)
{
    const Op op;

#if __loongarch_sx
#if __loongarch_asx
    if (elempack == 8)
    {
        __m256 _p = bfloat2float_lasx((__m128i)__lsx_vld(ptr, 0));
        for (int i = 0; i < w; i++)
        {
            __m256 _b = __lasx_xvreplfr2vr_s(bfloat16_to_float32(*ptr1));
            __m256 _outp = op(_p, _b);
            __lsx_vst(float2bfloat_lasx(_outp), outptr, 0);
            ptr1 += 1;
            outptr += 8;
        }
    }
#else  // __loongarch_asx
    if (elempack == 8)
    {
        __m128i _zero = __lsx_vreplgr2vr_w(0);
        __m128i _p01 = __lsx_vld(ptr, 0);
        __m128 _p0 = (__m128)__lsx_vilvl_h(_p01, _zero);
        __m128 _p1 = (__m128)__lsx_vilvh_h(_p01, _zero);
        for (int i = 0; i < w; i++)
        {
            __m128 _b = (__m128)__lsx_vreplfr2vr_s(bfloat16_to_float32(*ptr1));
            __m128 _outp0 = op(_p0, _b);
            __m128 _outp1 = op(_p1, _b);
            __lsx_vst(float2bfloat_lsx(_outp0, _outp1), outptr, 0);
            ptr1 += 1;
            outptr += 8;
        }
    }
#endif // __loongarch_asx

    if (elempack == 4)
    {
        __m128 _p = bfloat2float_lsx(__lsx_vldrepl_d(ptr, 0));
        int i = 0;
        for (; i + 1 < w; i += 2)
        {
            __m128 _b0 = (__m128)__lsx_vreplfr2vr_s(bfloat16_to_float32(ptr1[0]));
            __m128 _b1 = (__m128)__lsx_vreplfr2vr_s(bfloat16_to_float32(ptr1[1]));
            __m128 _outp0 = op(_p, _b0);
            __m128 _outp1 = op(_p, _b1);
            __lsx_vst(float2bfloat_lsx(_outp0, _outp1), outptr, 0);
            ptr1 += 2;
            outptr += 8;
        }
        for (; i < w; i++)
        {
            __m128 _b = (__m128)__lsx_vreplfr2vr_s(bfloat16_to_float32(*ptr1));
            __m128 _outp = op(_p, _b);
            __lsx_vstelm_d(float2bfloat_lsx(_outp), outptr, 0, 0);
            ptr1 += 1;
            outptr += 4;
        }
    }
#endif // __loongarch_sx
}

template<typename Op>
static void binary_op_vector_bf16s(const unsigned short* ptr, const unsigned short* ptr1, unsigned short* outptr, int aw, int bw, int ap, int bp)
{
    const int w = std::max(aw, bw);
    const int elempack = std::max(ap, bp);
    const int size = w * elempack;

    if (ap == bp)
    {
        if (aw == bw)
            return binary_op_vector_no_broadcast_bf16s<Op>(ptr, ptr1, outptr, size);
        if (bw == 1)
            return binary_op_vector_broadcast_b_bf16s<Op>(ptr, ptr1, outptr, size, elempack);
        if (aw == 1)
            return binary_op_vector_broadcast_a_bf16s<Op>(ptr, ptr1, outptr, size, elempack);
    }

    if (bp == 1)
    {
        if (aw == bw)
            return binary_op_vector_broadcast_pb_bf16s<Op>(ptr, ptr1, outptr, w, elempack);
        if (bw == 1)
            return binary_op_vector_broadcast_pb_b_bf16s<Op>(ptr, ptr1, outptr, w, elempack);
        if (aw == 1)
            return binary_op_vector_broadcast_pb_a_bf16s<Op>(ptr, ptr1, outptr, w, elempack);
    }
}
#endif // NCNN_BF16

static void binary_op_vector(const float* ptr, const float* ptr1, float* outptr, int aw, int bw, int ap, int bp, int op_type)
{
    using namespace BinaryOp_loongarch_functor;

    if (op_type == BinaryOp::Operation_ADD) return binary_op_vector<binary_op_add>(ptr, ptr1, outptr, aw, bw, ap, bp);
    if (op_type == BinaryOp::Operation_SUB) return binary_op_vector<binary_op_sub>(ptr, ptr1, outptr, aw, bw, ap, bp);
    if (op_type == BinaryOp::Operation_MUL) return binary_op_vector<binary_op_mul>(ptr, ptr1, outptr, aw, bw, ap, bp);
    if (op_type == BinaryOp::Operation_DIV) return binary_op_vector<binary_op_div>(ptr, ptr1, outptr, aw, bw, ap, bp);
    if (op_type == BinaryOp::Operation_MAX) return binary_op_vector<binary_op_max>(ptr, ptr1, outptr, aw, bw, ap, bp);
    if (op_type == BinaryOp::Operation_MIN) return binary_op_vector<binary_op_min>(ptr, ptr1, outptr, aw, bw, ap, bp);
    if (op_type == BinaryOp::Operation_POW) return binary_op_vector<binary_op_pow>(ptr, ptr1, outptr, aw, bw, ap, bp);
    if (op_type == BinaryOp::Operation_RSUB) return binary_op_vector<binary_op_rsub>(ptr, ptr1, outptr, aw, bw, ap, bp);
    if (op_type == BinaryOp::Operation_RDIV) return binary_op_vector<binary_op_rdiv>(ptr, ptr1, outptr, aw, bw, ap, bp);
    if (op_type == BinaryOp::Operation_RPOW) return binary_op_vector<binary_op_rpow>(ptr, ptr1, outptr, aw, bw, ap, bp);
    if (op_type == BinaryOp::Operation_ATAN2) return binary_op_vector<binary_op_atan2>(ptr, ptr1, outptr, aw, bw, ap, bp);
    if (op_type == BinaryOp::Operation_RATAN2) return binary_op_vector<binary_op_ratan2>(ptr, ptr1, outptr, aw, bw, ap, bp);
    if (op_type == BinaryOp::Operation_FMOD) return binary_op_vector<binary_op_fmod>(ptr, ptr1, outptr, aw, bw, ap, bp);
    if (op_type == BinaryOp::Operation_RFMOD) return binary_op_vector<binary_op_rfmod>(ptr, ptr1, outptr, aw, bw, ap, bp);
    if (op_type == BinaryOp::Operation_LOGADDEXP) return binary_op_vector<binary_op_logaddexp>(ptr, ptr1, outptr, aw, bw, ap, bp);
    if (op_type == BinaryOp::Operation_FLOOR_DIVIDE) return binary_op_vector<binary_op_floor_divide>(ptr, ptr1, outptr, aw, bw, ap, bp);
    if (op_type == BinaryOp::Operation_RFLOOR_DIVIDE) return binary_op_vector<binary_op_rfloor_divide>(ptr, ptr1, outptr, aw, bw, ap, bp);
    if (op_type == BinaryOp::Operation_REMAINDER) return binary_op_vector<binary_op_remainder>(ptr, ptr1, outptr, aw, bw, ap, bp);
    if (op_type == BinaryOp::Operation_RREMAINDER) return binary_op_vector<binary_op_rremainder>(ptr, ptr1, outptr, aw, bw, ap, bp);

    // should never reach here
}

static void binary_op_scalar(const Mat& a, float b, Mat& c, int op_type, const Option& opt)
{
    const int channels = a.c;
    const int size = a.w * a.h * a.d * a.elempack;

    #pragma omp parallel for num_threads(opt.num_threads)
    for (int q = 0; q < channels; q++)
    {
        const float* ptr = a.channel(q);
        float* outptr = c.channel(q);

        binary_op_vector(ptr, &b, outptr, size, 1, 1, 1, op_type);
    }
}

static void binary_op_no_broadcast(const Mat& a, const Mat& b, Mat& c, int op_type, const Option& opt)
{
    const int channels = a.c;
    const int size = a.w * a.h * a.d * a.elempack;

    #pragma omp parallel for num_threads(opt.num_threads)
    for (int q = 0; q < channels; q++)
    {
        const float* ptr = a.channel(q);
        const float* ptr1 = b.channel(q);
        float* outptr = c.channel(q);

        binary_op_vector(ptr, ptr1, outptr, size, size, 1, 1, op_type);
    }
}

static void binary_op_broadcast(const Mat& a, const Mat& b, Mat& c, int op_type, const Option& opt)
{
    if (b.w * b.h * b.d * b.c * b.elempack == 1)
    {
        return binary_op_scalar(a, b[0], c, op_type, opt);
    }

    if (a.dims == b.dims && a.w == b.w && a.h == b.h && a.d == b.d && a.c == b.c && a.elempack == b.elempack)
    {
        return binary_op_no_broadcast(a, b, c, op_type, opt);
    }

    const int dims = c.dims;

    if (dims == 2)
    {
        const int h = c.h;

        #pragma omp parallel for num_threads(opt.num_threads)
        for (int y = 0; y < h; y++)
        {
            const int y0 = std::min(y, a.h - 1);
            const int y1 = std::min(y, b.h - 1);

            const float* ptr = a.row(y0);
            const float* ptr1 = b.row(y1);
            float* outptr = c.row(y);

            binary_op_vector(ptr, ptr1, outptr, a.w, b.w, a.elempack, b.elempack, op_type);
        }
    }

    if (dims == 3 || dims == 4)
    {
        const int channels = c.c;

        #pragma omp parallel for num_threads(opt.num_threads)
        for (int q = 0; q < channels; q++)
        {
            const int q0 = std::min(q, a.c - 1);
            const int q1 = std::min(q, b.c - 1);

            if (b.d * b.h * b.w == 1)
            {
                const float* ptr = a.channel(q0);
                const float* ptr1 = b.channel(q1);
                float* outptr = c.channel(q);

                binary_op_vector(ptr, ptr1, outptr, a.w * a.h * a.d, 1, a.elempack, b.elempack, op_type);
                continue;
            }

            if (b.h * b.w == 1)
            {
                for (int z = 0; z < c.d; z++)
                {
                    const int z0 = std::min(z, a.d - 1);
                    const int z1 = std::min(z, b.d - 1);

                    const float* ptr = a.channel(q0).depth(z0);
                    const float* ptr1 = b.channel(q1).depth(z1);
                    float* outptr = c.channel(q).depth(z);

                    binary_op_vector(ptr, ptr1, outptr, a.w * a.h, 1, a.elempack, b.elempack, op_type);
                }
                continue;
            }

            for (int z = 0; z < c.d; z++)
            {
                const int z0 = std::min(z, a.d - 1);
                const int z1 = std::min(z, b.d - 1);

                for (int y = 0; y < c.h; y++)
                {
                    const int y0 = std::min(y, a.h - 1);
                    const int y1 = std::min(y, b.h - 1);

                    const float* ptr = a.channel(q0).depth(z0).row(y0);
                    const float* ptr1 = b.channel(q1).depth(z1).row(y1);
                    float* outptr = c.channel(q).depth(z).row(y);

                    binary_op_vector(ptr, ptr1, outptr, a.w, b.w, a.elempack, b.elempack, op_type);
                }
            }
        }
    }
}

static void binary_op_scalar_inplace(Mat& a, float b, int op_type, const Option& opt)
{
    const int channels = a.c;
    const int size = a.w * a.h * a.d * a.elempack;

    #pragma omp parallel for num_threads(opt.num_threads)
    for (int q = 0; q < channels; q++)
    {
        float* ptr = a.channel(q);

        binary_op_vector(ptr, &b, ptr, size, 1, 1, 1, op_type);
    }
}

static int get_reverse_op_type(int op_type)
{
    if (op_type == BinaryOp::Operation_SUB) return BinaryOp::Operation_RSUB;
    if (op_type == BinaryOp::Operation_DIV) return BinaryOp::Operation_RDIV;
    if (op_type == BinaryOp::Operation_POW) return BinaryOp::Operation_RPOW;
    if (op_type == BinaryOp::Operation_ATAN2) return BinaryOp::Operation_RATAN2;
    if (op_type == BinaryOp::Operation_FMOD) return BinaryOp::Operation_RFMOD;
    if (op_type == BinaryOp::Operation_LOGADDEXP) return BinaryOp::Operation_LOGADDEXP;
    if (op_type == BinaryOp::Operation_FLOOR_DIVIDE) return BinaryOp::Operation_RFLOOR_DIVIDE;
    if (op_type == BinaryOp::Operation_REMAINDER) return BinaryOp::Operation_RREMAINDER;

    if (op_type == BinaryOp::Operation_RSUB) return BinaryOp::Operation_SUB;
    if (op_type == BinaryOp::Operation_RDIV) return BinaryOp::Operation_DIV;
    if (op_type == BinaryOp::Operation_RPOW) return BinaryOp::Operation_POW;
    if (op_type == BinaryOp::Operation_RATAN2) return BinaryOp::Operation_ATAN2;
    if (op_type == BinaryOp::Operation_RFMOD) return BinaryOp::Operation_FMOD;
    if (op_type == BinaryOp::Operation_RFLOOR_DIVIDE) return BinaryOp::Operation_FLOOR_DIVIDE;
    if (op_type == BinaryOp::Operation_RREMAINDER) return BinaryOp::Operation_REMAINDER;

    return op_type;
}

int BinaryOp_loongarch::forward(const std::vector<Mat>& bottom_blobs, std::vector<Mat>& top_blobs, const Option& opt) const
{
#if NCNN_BF16
    int elembits = std::max(bottom_blobs[0].elembits(), bottom_blobs[1].elembits());
    if (opt.use_bf16_storage && elembits == 16)
        return forward_bf16s(bottom_blobs, top_blobs, opt);
#endif

    const Mat& A = bottom_blobs[0];
    const Mat& B = bottom_blobs[1];
    const int outdims = std::max(A.dims, B.dims);

    Mat A2 = A;
    Mat B2 = B;
    if (A.dims < outdims)
    {
        // expand inner axes
        if (outdims == 2)
        {
            if (A.w * A.elempack == B.h * B.elempack)
                A2 = A.reshape(1, A.w, opt.workspace_allocator);
            else // if (A.w == B.w)
            {
                A2.dims = 2;
                A2.w = A.w * A.elempack;
                A2.elempack = 1;
                A2.elemsize = A.elemsize / A.elempack;
                A2.cstep = A.cstep * A.elempack;
            }
        }
        if (outdims == 3 && A.dims == 1)
        {
            if (A.w * A.elempack == B.c * B.elempack)
                A2 = A.reshape(1, 1, A.w, opt.workspace_allocator);
            else // if (A.w == B.w)
            {
                A2.dims = 3;
                A2.w = A.w * A.elempack;
                A2.elempack = 1;
                A2.elemsize = A.elemsize / A.elempack;
                A2.cstep = A.cstep * A.elempack;
            }
        }
        if (outdims == 3 && A.dims == 2)
            A2 = A.reshape(1, A.w, A.h, opt.workspace_allocator);
        if (outdims == 4 && A.dims == 1)
        {
            if (A.w * A.elempack == B.c * B.elempack)
                A2 = A.reshape(1, 1, 1, A.w, opt.workspace_allocator);
            else // if (A.w == B.w)
            {
                A2.dims = 4;
                A2.w = A.w * A.elempack;
                A2.elempack = 1;
                A2.elemsize = A.elemsize / A.elempack;
                A2.cstep = A.cstep * A.elempack;
            }
        }
        if (outdims == 4 && A.dims == 2)
            A2 = A.reshape(1, 1, A.w, A.h, opt.workspace_allocator);
        if (outdims == 4 && A.dims == 3)
            A2 = A.reshape(1, A.w, A.h, A.c, opt.workspace_allocator);
    }
    if (B.dims < outdims)
    {
        // expand inner axes
        if (outdims == 2)
        {
            if (B.w * B.elempack == A.h * A.elempack)
                B2 = B.reshape(1, B.w, opt.workspace_allocator);
            else // if (B.w == A.w)
            {
                B2.dims = 2;
                B2.w = B.w * B.elempack;
                B2.elempack = 1;
                B2.elemsize = B.elemsize / B.elempack;
                B2.cstep = B.cstep * B.elempack;
            }
        }
        if (outdims == 3 && B.dims == 1)
        {
            if (B.w * B.elempack == A.c * A.elempack)
                B2 = B.reshape(1, 1, B.w, opt.workspace_allocator);
            else // if (B.w == A.w)
            {
                B2.dims = 3;
                B2.w = B.w * B.elempack;
                B2.elempack = 1;
                B2.elemsize = B.elemsize / B.elempack;
                B2.cstep = B.cstep * B.elempack;
            }
        }
        if (outdims == 3 && B.dims == 2)
            B2 = B.reshape(1, B.w, B.h, opt.workspace_allocator);
        if (outdims == 4 && B.dims == 1)
        {
            if (B.w * B.elempack == A.c * A.elempack)
                B2 = B.reshape(1, 1, 1, B.w, opt.workspace_allocator);
            else // if (B.w == A.w)
            {
                B2.dims = 4;
                B2.w = B.w * B.elempack;
                B2.elempack = 1;
                B2.elemsize = B.elemsize / B.elempack;
                B2.cstep = B.cstep * B.elempack;
            }
        }
        if (outdims == 4 && B.dims == 2)
            B2 = B.reshape(1, 1, B.w, B.h, opt.workspace_allocator);
        if (outdims == 4 && B.dims == 3)
            B2 = B.reshape(1, B.w, B.h, B.c, opt.workspace_allocator);
    }

    const int outw = std::max(A2.w, B2.w);
    const int outh = std::max(A2.h, B2.h);
    const int outd = std::max(A2.d, B2.d);
    const int outc = std::max(A2.c, B2.c);
    const size_t out_elemsize = std::max(A2.elemsize, B2.elemsize);
    const int out_elempack = std::max(A2.elempack, B2.elempack);

    Mat& top_blob = top_blobs[0];
    if (outdims == 1)
    {
        top_blob.create(outw, out_elemsize, out_elempack, opt.blob_allocator);
    }
    if (outdims == 2)
    {
        top_blob.create(outw, outh, out_elemsize, out_elempack, opt.blob_allocator);
    }
    if (outdims == 3)
    {
        top_blob.create(outw, outh, outc, out_elemsize, out_elempack, opt.blob_allocator);
    }
    if (outdims == 4)
    {
        top_blob.create(outw, outh, outd, outc, out_elemsize, out_elempack, opt.blob_allocator);
    }
    if (top_blob.empty())
        return -100;

    const bool a_pack_is_lower = A2.elempack < B2.elempack;
    const bool a_pack_is_equal = A2.elempack == B2.elempack;
    const bool a_size_is_lower = A2.w * A2.h * A2.d * A2.c * A2.elempack < B2.w * B2.h * B2.d * B2.c * B2.elempack;
    if (a_pack_is_lower || (a_pack_is_equal && a_size_is_lower))
    {
        binary_op_broadcast(B2, A2, top_blob, get_reverse_op_type(op_type), opt);
    }
    else
    {
        binary_op_broadcast(A2, B2, top_blob, op_type, opt);
    }

    return 0;
}

int BinaryOp_loongarch::forward_inplace(Mat& bottom_top_blob, const Option& opt) const
{
#if NCNN_BF16
    if (opt.use_bf16_storage && bottom_top_blob.elembits() == 16)
        return forward_inplace_bf16s(bottom_top_blob, opt);
#endif

    binary_op_scalar_inplace(bottom_top_blob, b, op_type, opt);

    return 0;
}

#if NCNN_BF16
static void binary_op_vector_bf16s(const unsigned short* ptr, const unsigned short* ptr1, unsigned short* outptr, int aw, int bw, int ap, int bp, int op_type)
{
    using namespace BinaryOp_loongarch_functor;

    if (op_type == BinaryOp::Operation_ADD) return binary_op_vector_bf16s<binary_op_add>(ptr, ptr1, outptr, aw, bw, ap, bp);
    if (op_type == BinaryOp::Operation_SUB) return binary_op_vector_bf16s<binary_op_sub>(ptr, ptr1, outptr, aw, bw, ap, bp);
    if (op_type == BinaryOp::Operation_MUL) return binary_op_vector_bf16s<binary_op_mul>(ptr, ptr1, outptr, aw, bw, ap, bp);
    if (op_type == BinaryOp::Operation_DIV) return binary_op_vector_bf16s<binary_op_div>(ptr, ptr1, outptr, aw, bw, ap, bp);
    if (op_type == BinaryOp::Operation_MAX) return binary_op_vector_bf16s<binary_op_max>(ptr, ptr1, outptr, aw, bw, ap, bp);
    if (op_type == BinaryOp::Operation_MIN) return binary_op_vector_bf16s<binary_op_min>(ptr, ptr1, outptr, aw, bw, ap, bp);
    if (op_type == BinaryOp::Operation_POW) return binary_op_vector_bf16s<binary_op_pow>(ptr, ptr1, outptr, aw, bw, ap, bp);
    if (op_type == BinaryOp::Operation_RSUB) return binary_op_vector_bf16s<binary_op_rsub>(ptr, ptr1, outptr, aw, bw, ap, bp);
    if (op_type == BinaryOp::Operation_RDIV) return binary_op_vector_bf16s<binary_op_rdiv>(ptr, ptr1, outptr, aw, bw, ap, bp);
    if (op_type == BinaryOp::Operation_RPOW) return binary_op_vector_bf16s<binary_op_rpow>(ptr, ptr1, outptr, aw, bw, ap, bp);
    if (op_type == BinaryOp::Operation_ATAN2) return binary_op_vector_bf16s<binary_op_atan2>(ptr, ptr1, outptr, aw, bw, ap, bp);
    if (op_type == BinaryOp::Operation_RATAN2) return binary_op_vector_bf16s<binary_op_ratan2>(ptr, ptr1, outptr, aw, bw, ap, bp);
    if (op_type == BinaryOp::Operation_FMOD) return binary_op_vector_bf16s<binary_op_fmod>(ptr, ptr1, outptr, aw, bw, ap, bp);
    if (op_type == BinaryOp::Operation_RFMOD) return binary_op_vector_bf16s<binary_op_rfmod>(ptr, ptr1, outptr, aw, bw, ap, bp);
    if (op_type == BinaryOp::Operation_LOGADDEXP) return binary_op_vector_bf16s<binary_op_logaddexp>(ptr, ptr1, outptr, aw, bw, ap, bp);
    if (op_type == BinaryOp::Operation_FLOOR_DIVIDE) return binary_op_vector_bf16s<binary_op_floor_divide>(ptr, ptr1, outptr, aw, bw, ap, bp);
    if (op_type == BinaryOp::Operation_RFLOOR_DIVIDE) return binary_op_vector_bf16s<binary_op_rfloor_divide>(ptr, ptr1, outptr, aw, bw, ap, bp);
    if (op_type == BinaryOp::Operation_REMAINDER) return binary_op_vector_bf16s<binary_op_remainder>(ptr, ptr1, outptr, aw, bw, ap, bp);
    if (op_type == BinaryOp::Operation_RREMAINDER) return binary_op_vector_bf16s<binary_op_rremainder>(ptr, ptr1, outptr, aw, bw, ap, bp);

    // should never reach here
}

static void binary_op_scalar_bf16s(const Mat& a, unsigned short b, Mat& c, int op_type, const Option& opt)
{
    const int channels = a.c;
    const int size = a.w * a.h * a.d * a.elempack;

    #pragma omp parallel for num_threads(opt.num_threads)
    for (int q = 0; q < channels; q++)
    {
        const unsigned short* ptr = a.channel(q);
        unsigned short* outptr = c.channel(q);

        binary_op_vector_bf16s(ptr, &b, outptr, size, 1, 1, 1, op_type);
    }
}

static void binary_op_no_broadcast_bf16s(const Mat& a, const Mat& b, Mat& c, int op_type, const Option& opt)
{
    const int channels = a.c;
    const int size = a.w * a.h * a.d * a.elempack;

    #pragma omp parallel for num_threads(opt.num_threads)
    for (int q = 0; q < channels; q++)
    {
        const unsigned short* ptr = a.channel(q);
        const unsigned short* ptr1 = b.channel(q);
        unsigned short* outptr = c.channel(q);

        binary_op_vector_bf16s(ptr, ptr1, outptr, size, size, 1, 1, op_type);
    }
}

static void binary_op_broadcast_bf16s(const Mat& a, const Mat& b, Mat& c, int op_type, const Option& opt)
{
    if (b.w * b.h * b.d * b.c * b.elempack == 1)
    {
        return binary_op_scalar_bf16s(a, ((const unsigned short*)b)[0], c, op_type, opt);
    }

    if (a.dims == b.dims && a.w == b.w && a.h == b.h && a.d == b.d && a.c == b.c && a.elempack == b.elempack)
    {
        return binary_op_no_broadcast_bf16s(a, b, c, op_type, opt);
    }

    const int dims = c.dims;

    if (dims == 2)
    {
        const int h = c.h;

        #pragma omp parallel for num_threads(opt.num_threads)
        for (int y = 0; y < h; y++)
        {
            const int y0 = std::min(y, a.h - 1);
            const int y1 = std::min(y, b.h - 1);

            const unsigned short* ptr = a.row<const unsigned short>(y0);
            const unsigned short* ptr1 = b.row<const unsigned short>(y1);
            unsigned short* outptr = c.row<unsigned short>(y);

            binary_op_vector_bf16s(ptr, ptr1, outptr, a.w, b.w, a.elempack, b.elempack, op_type);
        }
    }

    if (dims == 3 || dims == 4)
    {
        const int channels = c.c;

        #pragma omp parallel for num_threads(opt.num_threads)
        for (int q = 0; q < channels; q++)
        {
            const int q0 = std::min(q, a.c - 1);
            const int q1 = std::min(q, b.c - 1);

            if (b.d * b.h * b.w == 1)
            {
                const unsigned short* ptr = a.channel(q0);
                const unsigned short* ptr1 = b.channel(q1);
                unsigned short* outptr = c.channel(q);

                binary_op_vector_bf16s(ptr, ptr1, outptr, a.w * a.h * a.d, 1, a.elempack, b.elempack, op_type);
                continue;
            }

            if (b.h * b.w == 1)
            {
                for (int z = 0; z < c.d; z++)
                {
                    const int z0 = std::min(z, a.d - 1);
                    const int z1 = std::min(z, b.d - 1);

                    const unsigned short* ptr = a.channel(q0).depth(z0);
                    const unsigned short* ptr1 = b.channel(q1).depth(z1);
                    unsigned short* outptr = c.channel(q).depth(z);

                    binary_op_vector_bf16s(ptr, ptr1, outptr, a.w * a.h, 1, a.elempack, b.elempack, op_type);
                }
                continue;
            }

            for (int z = 0; z < c.d; z++)
            {
                const int z0 = std::min(z, a.d - 1);
                const int z1 = std::min(z, b.d - 1);

                for (int y = 0; y < c.h; y++)
                {
                    const int y0 = std::min(y, a.h - 1);
                    const int y1 = std::min(y, b.h - 1);

                    const unsigned short* ptr = a.channel(q0).depth(z0).row<const unsigned short>(y0);
                    const unsigned short* ptr1 = b.channel(q1).depth(z1).row<const unsigned short>(y1);
                    unsigned short* outptr = c.channel(q).depth(z).row<unsigned short>(y);

                    binary_op_vector_bf16s(ptr, ptr1, outptr, a.w, b.w, a.elempack, b.elempack, op_type);
                }
            }
        }
    }
}

static void binary_op_scalar_inplace_bf16s(Mat& a, unsigned short b, int op_type, const Option& opt)
{
    const int channels = a.c;
    const int size = a.w * a.h * a.d * a.elempack;

    #pragma omp parallel for num_threads(opt.num_threads)
    for (int q = 0; q < channels; q++)
    {
        unsigned short* ptr = a.channel(q);

        binary_op_vector_bf16s(ptr, &b, ptr, size, 1, 1, 1, op_type);
    }
}

int BinaryOp_loongarch::forward_bf16s(const std::vector<Mat>& bottom_blobs, std::vector<Mat>& top_blobs, const Option& opt) const
{
    const Mat& A = bottom_blobs[0];
    const Mat& B = bottom_blobs[1];
    const int outdims = std::max(A.dims, B.dims);

    Mat A2 = A;
    Mat B2 = B;
    if (A.dims < outdims)
    {
        // expand inner axes
        if (outdims == 2)
        {
            if (A.w * A.elempack == B.h * B.elempack)
                A2 = A.reshape(1, A.w, opt.workspace_allocator);
            else // if (A.w == B.w)
            {
                A2.dims = 2;
                A2.w = A.w * A.elempack;
                A2.elempack = 1;
                A2.elemsize = A.elemsize / A.elempack;
                A2.cstep = A.cstep * A.elempack;
            }
        }
        if (outdims == 3 && A.dims == 1)
        {
            if (A.w * A.elempack == B.c * B.elempack)
                A2 = A.reshape(1, 1, A.w, opt.workspace_allocator);
            else // if (A.w == B.w)
            {
                A2.dims = 3;
                A2.w = A.w * A.elempack;
                A2.elempack = 1;
                A2.elemsize = A.elemsize / A.elempack;
                A2.cstep = A.cstep * A.elempack;
            }
        }
        if (outdims == 3 && A.dims == 2)
            A2 = A.reshape(1, A.w, A.h, opt.workspace_allocator);
        if (outdims == 4 && A.dims == 1)
        {
            if (A.w * A.elempack == B.c * B.elempack)
                A2 = A.reshape(1, 1, 1, A.w, opt.workspace_allocator);
            else // if (A.w == B.w)
            {
                A2.dims = 4;
                A2.w = A.w * A.elempack;
                A2.elempack = 1;
                A2.elemsize = A.elemsize / A.elempack;
                A2.cstep = A.cstep * A.elempack;
            }
        }
        if (outdims == 4 && A.dims == 2)
            A2 = A.reshape(1, 1, A.w, A.h, opt.workspace_allocator);
        if (outdims == 4 && A.dims == 3)
            A2 = A.reshape(1, A.w, A.h, A.c, opt.workspace_allocator);
    }
    if (B.dims < outdims)
    {
        // expand inner axes
        if (outdims == 2)
        {
            if (B.w * B.elempack == A.h * A.elempack)
                B2 = B.reshape(1, B.w, opt.workspace_allocator);
            else // if (B.w == A.w)
            {
                B2.dims = 2;
                B2.w = B.w * B.elempack;
                B2.elempack = 1;
                B2.elemsize = B.elemsize / B.elempack;
                B2.cstep = B.cstep * B.elempack;
            }
        }
        if (outdims == 3 && B.dims == 1)
        {
            if (B.w * B.elempack == A.c * A.elempack)
                B2 = B.reshape(1, 1, B.w, opt.workspace_allocator);
            else // if (B.w == A.w)
            {
                B2.dims = 3;
                B2.w = B.w * B.elempack;
                B2.elempack = 1;
                B2.elemsize = B.elemsize / B.elempack;
                B2.cstep = B.cstep * B.elempack;
            }
        }
        if (outdims == 3 && B.dims == 2)
            B2 = B.reshape(1, B.w, B.h, opt.workspace_allocator);
        if (outdims == 4 && B.dims == 1)
        {
            if (B.w * B.elempack == A.c * A.elempack)
                B2 = B.reshape(1, 1, 1, B.w, opt.workspace_allocator);
            else // if (B.w == A.w)
            {
                B2.dims = 4;
                B2.w = B.w * B.elempack;
                B2.elempack = 1;
                B2.elemsize = B.elemsize / B.elempack;
                B2.cstep = B.cstep * B.elempack;
            }
        }
        if (outdims == 4 && B.dims == 2)
            B2 = B.reshape(1, 1, B.w, B.h, opt.workspace_allocator);
        if (outdims == 4 && B.dims == 3)
            B2 = B.reshape(1, B.w, B.h, B.c, opt.workspace_allocator);
    }

    const int outw = std::max(A2.w, B2.w);
    const int outh = std::max(A2.h, B2.h);
    const int outd = std::max(A2.d, B2.d);
    const int outc = std::max(A2.c, B2.c);
    const size_t out_elemsize = std::max(A2.elemsize, B2.elemsize);
    const int out_elempack = std::max(A2.elempack, B2.elempack);

    Mat& top_blob = top_blobs[0];
    if (outdims == 1)
    {
        top_blob.create(outw, out_elemsize, out_elempack, opt.blob_allocator);
    }
    if (outdims == 2)
    {
        top_blob.create(outw, outh, out_elemsize, out_elempack, opt.blob_allocator);
    }
    if (outdims == 3)
    {
        top_blob.create(outw, outh, outc, out_elemsize, out_elempack, opt.blob_allocator);
    }
    if (outdims == 4)
    {
        top_blob.create(outw, outh, outd, outc, out_elemsize, out_elempack, opt.blob_allocator);
    }
    if (top_blob.empty())
        return -100;

    const bool a_pack_is_lower = A2.elempack < B2.elempack;
    const bool a_pack_is_equal = A2.elempack == B2.elempack;
    const bool a_size_is_lower = A2.w * A2.h * A2.d * A2.c * A2.elempack < B2.w * B2.h * B2.d * B2.c * B2.elempack;
    if (a_pack_is_lower || (a_pack_is_equal && a_size_is_lower))
    {
        binary_op_broadcast_bf16s(B2, A2, top_blob, get_reverse_op_type(op_type), opt);
    }
    else
    {
        binary_op_broadcast_bf16s(A2, B2, top_blob, op_type, opt);
    }

    return 0;
}

int BinaryOp_loongarch::forward_inplace_bf16s(Mat& bottom_top_blob, const Option& opt) const
{
    binary_op_scalar_inplace_bf16s(bottom_top_blob, float32_to_bfloat16(b), op_type, opt);

    return 0;
}
#endif // NCNN_BF16

} // namespace ncnn
