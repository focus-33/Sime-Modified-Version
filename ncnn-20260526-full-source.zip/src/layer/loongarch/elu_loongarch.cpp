// Copyright 2026 Tencent
// SPDX-License-Identifier: BSD-3-Clause

#include "elu_loongarch.h"

#if __loongarch_sx
#include <lsxintrin.h>
#include "loongarch_usability.h"
#include "lsx_mathfun.h"
#if __loongarch_asx
#include <lasxintrin.h>
#include "lasx_mathfun.h"
#endif // __loongarch_asx
#endif // __loongarch_sx

namespace ncnn {

ELU_loongarch::ELU_loongarch()
{
#if __loongarch_sx
    support_packing = true;
    support_any_packing = true;
#endif
#if NCNN_BF16
    support_bf16_storage = true;
#endif
}

int ELU_loongarch::forward_inplace(Mat& bottom_top_blob, const Option& opt) const
{
#if NCNN_BF16
    if (opt.use_bf16_storage && bottom_top_blob.elembits() == 16)
        return forward_inplace_bf16s(bottom_top_blob, opt);
#endif

    int w = bottom_top_blob.w;
    int h = bottom_top_blob.h;
    int d = bottom_top_blob.d;
    int channels = bottom_top_blob.c;
    int elempack = bottom_top_blob.elempack;
    int size = w * h * d * elempack;

    #pragma omp parallel for num_threads(opt.num_threads)
    for (int q = 0; q < channels; q++)
    {
        float* ptr = bottom_top_blob.channel(q);

        int i = 0;
#if __loongarch_sx
#if __loongarch_asx
        __m256 _zero8 = (__m256)__lasx_xvreplgr2vr_w(0);
        __m256 _one8 = (__m256)__lasx_xvreplfr2vr_s(1.f);
        __m256 _alpha8 = (__m256)__lasx_xvreplfr2vr_s(alpha);
        for (; i + 7 < size; i += 8)
        {
            __builtin_prefetch(ptr + 32);

            __m256 _p = (__m256)__lasx_xvld(ptr, 0);
            __m256 _pos = __lasx_xvfmax_s(_p, _zero8);
            __m256 _neg = __lasx_xvfmin_s(_p, _zero8);
            __m256 _outp = exp256_ps(_neg);
            _outp = __lasx_xvfsub_s(_outp, _one8);
            _outp = __lasx_xvfmul_s(_outp, _alpha8);
            _outp = __lasx_xvfadd_s(_outp, _pos);
            __lasx_xvst(_outp, ptr, 0);

            ptr += 8;
        }
#endif
        __m128 _zero4 = (__m128)__lsx_vreplgr2vr_w(0);
        __m128 _one4 = (__m128)__lsx_vreplfr2vr_s(1.f);
        __m128 _alpha4 = (__m128)__lsx_vreplfr2vr_s(alpha);
        for (; i + 3 < size; i += 4)
        {
            __builtin_prefetch(ptr + 16);

            __m128 _p = (__m128)__lsx_vld(ptr, 0);
            __m128 _pos = __lsx_vfmax_s(_p, _zero4);
            __m128 _neg = __lsx_vfmin_s(_p, _zero4);
            __m128 _outp = exp_ps(_neg);
            _outp = __lsx_vfsub_s(_outp, _one4);
            _outp = __lsx_vfmul_s(_outp, _alpha4);
            _outp = __lsx_vfadd_s(_outp, _pos);
            __lsx_vst(_outp, ptr, 0);

            ptr += 4;
        }
#endif
        for (; i < size; i++)
        {
            if (*ptr < 0.f)
                *ptr = alpha * (expf(*ptr) - 1.f);
            ptr++;
        }
    }

    return 0;
}

#if NCNN_BF16
int ELU_loongarch::forward_inplace_bf16s(Mat& bottom_top_blob, const Option& opt) const
{
    int w = bottom_top_blob.w;
    int h = bottom_top_blob.h;
    int d = bottom_top_blob.d;
    int channels = bottom_top_blob.c;
    int elempack = bottom_top_blob.elempack;
    int size = w * h * d * elempack;

    #pragma omp parallel for num_threads(opt.num_threads)
    for (int q = 0; q < channels; q++)
    {
        unsigned short* ptr = bottom_top_blob.channel(q);

        int i = 0;
#if __loongarch_sx
#if __loongarch_asx
        __m256 _zero8 = (__m256)__lasx_xvreplgr2vr_w(0);
        __m256 _one8 = (__m256)__lasx_xvreplfr2vr_s(1.f);
        __m256 _alpha8 = (__m256)__lasx_xvreplfr2vr_s(alpha);
        for (; i + 7 < size; i += 8)
        {
            __m256 _p = bfloat2float_lasx((__m128i*)ptr);
            __m256 _pos = __lasx_xvfmax_s(_p, _zero8);
            __m256 _neg = __lasx_xvfmin_s(_p, _zero8);
            __m256 _outp = exp256_ps(_neg);
            _outp = __lasx_xvfsub_s(_outp, _one8);
            _outp = __lasx_xvfmul_s(_outp, _alpha8);
            _outp = __lasx_xvfadd_s(_outp, _pos);
            __lsx_vst(float2bfloat_lasx(_outp), ptr, 0);
            ptr += 8;
        }
#else // __loongarch_asx
        {
            __m128i _zero_raw = __lsx_vreplgr2vr_w(0);
            __m128 _zero4 = (__m128)_zero_raw;
            __m128 _one4 = (__m128)__lsx_vreplfr2vr_s(1.f);
            __m128 _alpha4 = (__m128)__lsx_vreplfr2vr_s(alpha);
            for (; i + 7 < size; i += 8)
            {
                __m128i _p01 = __lsx_vld(ptr, 0);
                __m128 _p0 = (__m128)__lsx_vilvl_h(_p01, _zero_raw);
                __m128 _p1 = (__m128)__lsx_vilvh_h(_p01, _zero_raw);
                __m128 _pos0 = __lsx_vfmax_s(_p0, _zero4);
                __m128 _pos1 = __lsx_vfmax_s(_p1, _zero4);
                __m128 _neg0 = __lsx_vfmin_s(_p0, _zero4);
                __m128 _neg1 = __lsx_vfmin_s(_p1, _zero4);
                __m128 _outp0 = exp_ps(_neg0);
                __m128 _outp1 = exp_ps(_neg1);
                _outp0 = __lsx_vfsub_s(_outp0, _one4);
                _outp1 = __lsx_vfsub_s(_outp1, _one4);
                _outp0 = __lsx_vfmul_s(_outp0, _alpha4);
                _outp1 = __lsx_vfmul_s(_outp1, _alpha4);
                _outp0 = __lsx_vfadd_s(_outp0, _pos0);
                _outp1 = __lsx_vfadd_s(_outp1, _pos1);
                __lsx_vst(float2bfloat_lsx(_outp0, _outp1), ptr, 0);
                ptr += 8;
            }
        }
#endif
        __m128 _zero4 = (__m128)__lsx_vreplgr2vr_w(0);
        __m128 _one4 = (__m128)__lsx_vreplfr2vr_s(1.f);
        __m128 _alpha4 = (__m128)__lsx_vreplfr2vr_s(alpha);
        for (; i + 3 < size; i += 4)
        {
            __m128 _p = bfloat2float_lsx(__lsx_vldrepl_d(ptr, 0));
            __m128 _pos = __lsx_vfmax_s(_p, _zero4);
            __m128 _neg = __lsx_vfmin_s(_p, _zero4);
            __m128 _outp = exp_ps(_neg);
            _outp = __lsx_vfsub_s(_outp, _one4);
            _outp = __lsx_vfmul_s(_outp, _alpha4);
            _outp = __lsx_vfadd_s(_outp, _pos);
            __lsx_vstelm_d(float2bfloat_lsx(_outp), ptr, 0, 0);
            ptr += 4;
        }
#endif
        for (; i < size; i++)
        {
            float v = bfloat16_to_float32(*ptr);
            if (v < 0.f)
                v = alpha * (expf(v) - 1.f);
            *ptr = float32_to_bfloat16(v);
            ptr++;
        }
    }

    return 0;
}
#endif // NCNN_BF16

} // namespace ncnn
